package gameStart;

public class Ch2 {
	
	ChPublic cp = new ChPublic();
	
	static MainCharacter player = new MainCharacter();

	public static void ch2(String monsterLv, int lv1MonsterDieCount, int Lv2MonsterHeartCount) {
		// MainCharacter player = new MainCharacter();
		ChPublic cp = new ChPublic();
		Monster lv2Monster = new MonsterKind("lv2Monster", 25, 60);
		Inventory inventory = new Inventory(); // 신진수 작업

		cp.startChapter("챕터2"); // 챕터 퀘스트 시작 메소드 - ChPublic
		cp.askQuest(player, "lv2Monster", 0, 10); // 퀘스트 문구 나오는 메소드 - ChPublic
		cp.beforeQuest(player, "lv2Monster", 0, 10);

		System.out.println("사냥을 시작합니다.");

		while (player.inventory.getLv2MonsterHeartCount() < 10) {
			while (lv2Monster.hp > 0) {
				System.out.println("");
				System.out.println("lv2Monster를 공격하시겠습니까?");
				System.out.println("1. 공격 \t 2. 포션먹기");
				int userChoice = cp.scannerInt();
				if (userChoice == 1) {
					System.out.println("lv2Monster를 공격합니다.");
					player.attack(lv2Monster);

					if (lv2Monster.hp <= 0) {
						System.out.println("lv2Monster를 잡았습니다!");
						player.inventory.setPortion_count(SelectJob.getRandomPortion());// 포션 메소드
						player.inventory.setLv2MonsterHeartCount(SelectJob.getRandomHeart());// 재료 메소드
						cp.acquireGoldAndTotal_money(inventory); // 아래 getGold(), getTotal_money() 통합.
						/*
						inventory.getGold(); // 신진수 작업
						inventory.getTotal_money(); // 신진수 작업
						*/

					} else {
						lv2Monster.attack(player);
						player.checkPlayerHP();
					}
				} else if (userChoice == 2) {
					player.drink(100);// 100이 포션 한번 먹을때 차는 양
					// System.out.println("물약을 사용하였습니다.");
					// System.out.println(player.getName() + "님의 현재 HP : " + player.getHuman_hp());
				}
			}

			lv2Monster = new MonsterKind(null, 25, 60);

			if (player.inventory.getLv2MonsterHeartCount() < 10) {
				System.out.println("");
				System.out.println("새로운 몬스터 사냥을 시작합니다!");
				// System.out.println("현재 lv2MonsterHeartCount 값: " +
				// inventory.getLv2MonsterHeartCount());
			} else if (player.inventory.getLv2MonsterHeartCount() == 10) {
				System.out.println("");
				System.out.println("챕터2 퀘스트를 클리어 하였습니다.");
				System.out.println("퀘스트 보상으로 300 골드를 추가 지급합니다.");
				inventory.total_money += 300;
				System.out.println(player.getName() + "님이 챕터2를 깰때까지 획득한 총 골드는 : " + inventory.total_money + "입니다.");// 신진수
																													// 작업
			}
		}
		System.out.println("챕터2 퀘스트를 클리어 하였습니다.");
	}

}
package gameStart;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StoreDAO {
	DBConnection dbConn = DBConnection.getInstance();

	// 재고목록 깔아주기(전사용)
	public List<StoreDTO> itemList1() {
		List<StoreDTO> list = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM Item1 WHERE I_Stock = 'O'";

		list = new ArrayList<StoreDTO>();
		conn = dbConn.getConn();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				StoreDTO e = new StoreDTO();
				e.setNumber(rs.getInt("I_NO"));
				e.setCode(rs.getString("I_Code"));
				e.setName(rs.getString("I_Name"));
				e.setPrice(rs.getInt("I_Price"));
				list.add(e);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);
		}

		return list;
	}

	// 입력받은 상품 가격 가져오기(전사용)
	public int itemPrice1(int no) {
		int price = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT I_Price FROM Item1 WHERE I_NO = ?";

		conn = dbConn.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				price = rs.getInt("I_Price");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return price;
	}
	
	// 입력받은 상품명 가져오기(전사용)
		public String itemName1(int no) {
			String name = "";
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "SELECT I_Name FROM Item1 WHERE I_NO = ?";

			conn = dbConn.getConn();

			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, no);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					name = rs.getString("I_Name");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return name;
		}

	// 아이템 스테이터스 Attack, Hp 받아오기(전사용)
	public Map<String, Integer> itemStatus1(int no) {
		Map<String, Integer> status = new HashMap<String, Integer>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT I_Attack, I_Hp FROM Item1 WHERE I_NO = ?";

		conn = dbConn.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				status.put("attack", rs.getInt("I_Attack"));
				status.put("hp", rs.getInt("I_Hp"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);
		}

		return status;
	}

	// 팔린 아이템 팔렸다고 표시하기(전사용)
	public void stockOut1(int no) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE Item1 SET I_Stock = 'X' WHERE I_NO = ?";

		conn = dbConn.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, pstmt, conn);
		}
	}
	
	// 상점 재고 초기화(전사용)
	public void initializeStock1() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE Item1 SET I_Stock = 'O'";

		conn = dbConn.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, pstmt, conn);
		}
	}

	
	// 재고목록 깔아주기(마법사용)
	public List<StoreDTO> itemList2() {
		List<StoreDTO> list = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM Item2 WHERE I_Stock = 'O'";

		list = new ArrayList<StoreDTO>();
		conn = dbConn.getConn();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				StoreDTO e = new StoreDTO();
				e.setNumber(rs.getInt("I_NO"));
				e.setCode(rs.getString("I_Code"));
				e.setName(rs.getString("I_Name"));
				e.setPrice(rs.getInt("I_Price"));
				list.add(e);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);
		}

		return list;
	}

	// 입력받은 상품 가격 가져오기(마법사용)
	public int itemPrice2(int no) {
		int price = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT I_Price FROM Item2 WHERE I_NO = ?";

		conn = dbConn.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				price = rs.getInt("I_Price");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return price;
	}
	
	// 입력받은 상품명 가져오기(마법사용)
		public String itemName2(int no) {
			String name = "";
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "SELECT I_Name FROM Item2 WHERE I_NO = ?";

			conn = dbConn.getConn();

			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, no);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					name = rs.getString("I_Name");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return name;
		}

	// 아이템 스테이터스 Attack, Hp 받아오기(마법사용)
	public Map<String, Integer> itemStatus2(int no) {
		Map<String, Integer> status = new HashMap<String, Integer>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT I_Attack, I_Hp FROM Item2 WHERE I_NO = ?";

		conn = dbConn.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				status.put("attack", rs.getInt("I_Attack"));
				status.put("hp", rs.getInt("I_Hp"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);
		}

		return status;
	}

	// 팔린 아이템 팔렸다고 표시하기(마법사용)
	public void stockOut2(int no) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE Item2 SET I_Stock = 'X' WHERE I_NO = ?";

		conn = dbConn.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, pstmt, conn);
		}
	}
	
	// 상점 재고 초기화(마법사용)
	public void initializeStock2() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE Item2 SET I_Stock = 'O'";

		conn = dbConn.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, pstmt, conn);
		}
	}

	
	//close
	private void close(ResultSet rs, PreparedStatement pstmt, Connection conn) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
}

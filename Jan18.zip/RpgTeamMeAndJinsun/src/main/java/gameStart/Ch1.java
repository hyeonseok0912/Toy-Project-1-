package gameStart;

import java.util.Scanner;

public class Ch1 {
	static MainCharacter player = new MainCharacter();
	ChPublic cp = new ChPublic();

	public static void ch1(String monsterLv) {
		ChPublic cp = new ChPublic();
		Monster lv1Monster = new MonsterKind("lv1Monster", 15, 20);
		Inventory inventory = new Inventory(); // 신진수 작업
		
		cp.startChapter("챕터1"); // 챕터 퀘스트 시작 메소드 - ChPublic
		cp.askQuest(player, "lv1Monster", 10, 0); // 퀘스트 문구 나오는 메소드 - ChPublic
		cp.beforeQuest(player, "lv1Monster", 10, 0);

		System.out.println("사냥을 시작합니다.");
		int lv1MonsterDieCount = 0;
		while (lv1MonsterDieCount < 10) {
			while (lv1Monster.hp > 0) {
				System.out.println("");
				System.out.println("lv1Monster를 공격하시겠습니까?");
				System.out.println("1. 공격 \t 2. 포션먹기");
				if (cp.scannerInt() == 1) {
					System.out.println("lv1Monster를 공격합니다.");
					player.attack(lv1Monster);
					if (lv1Monster.hp <= 0) {
						System.out.println("lv1Monster를 잡았습니다!");
						lv1MonsterDieCount++;
						System.out.println("");
						player.inventory.setPortion_count(SelectJob.getRandomPortion());// 포션 메소드

						cp.acquireGoldAndTotal_money(inventory); // 아래 getGold(), getTotal_money() 통합.

						System.out.println(player.getName() + "님의 현재 HP : " + player.getHuman_hp());
						System.out.println("현재 잡은 몬스터 마릿수 : " + lv1MonsterDieCount);

					} else {
//	              System.out.println("남은 lv1Monster의 hp는 : " + lv1Monster.hp);
						lv1Monster.attack(player);
						player.checkPlayerHP();
					}
				} else if (cp.scannerInt() == 2) {
					player.drink(100);// 100이 포션 한번 먹을때 차는 양
					// System.out.println("물약을 사용하였습니다.");
				}
			}
			if (lv1MonsterDieCount < 10) {
				System.out.println("");
				System.out.println("새로운 몬스터 사냥을 시작합니다!");
				lv1Monster = new MonsterKind(null, 15, 20);
			} else {
				System.out.println("챕터1 퀘스트를 클리어 하였습니다.");
				System.out.println("퀘스트 보상으로 300 골드를 추가 지급합니다.");
				// (코드로)인벤토리 클래스 내 토탈골드 + 300
				inventory.total_money += 300;
				System.out.println("현재까지 " + player.getName() + "님이 보유한 총 골드 : " + inventory.total_money + "입니다.");
			}

		}

	}

}
package gameStart;

import java.util.Scanner;

public class Main {
	BossMonster bm = new BossMonster("Java", 70, 500);
	
	public static void main(String[] args) {

		MainCharacter player = new MainCharacter();
		Store st = new Store();
		Ch1 ch1 = new Ch1();
		Ch2 ch2 = new Ch2();
		Ch3 ch3 = new Ch3();
		
		Scanner sc = new Scanner(System.in);

		Opening.OpeningMessage(sc);  // 오프닝 문을 사용하는 메소드
		
		ch1.ch1("lv1Monster");
		
	    st.shopping();
		ch2.ch2("lv2Monster", 0, 10);
		
	    st.shopping();
	    ch3.bossStart();  // 보스 퀘스트만 불러오기  quest.bossStart();  시작
	    
		System.out.println("모든 챕터 퀘스트를 완수하였습니다." + player.getName() + "님은 진정한 용사입니다.");
		System.out.println("-게임 끝-");
	}
}
package gameStart;

public class MainCharacter {

	Inventory inventory = new Inventory();
	static String name;
	static int human_attackPower; // private 제거
	static int human_hp; // private 제거
	int gold; // private 제거
	static int jobNum; // 직업 변수, 1이 전사 2가 마법사

	public String getName() {
		return name;
	}

	public static String getName2() {
		return name;
	}

	public void setName(String inputName) {
		name = inputName;
	}

	public int getHuman_hp() { // getUserId 메서드를 통해 userId 값을 다른 클래스에서 가져오기 위한 메소드
		return human_hp;
	}
	/*진수가 뺌. store랑 엮어있는 메소드
	public static int getHuman_hp2() { // getUserId 메서드를 통해 userId 값을 다른 클래스에서 가져오기 위한 메소드
		return human_hp;
	}
	*/
	public void setHuman_attackPower(int aP) {
		human_attackPower = aP;
	}

	public static void setHuman_attackPower2(int aP) {
		human_attackPower += aP;
	}

	public int getHuman_attackPower() { // getUserId 메서드를 통해 userId 값을 다른 클래스에서 가져오기 위한 메소드
		return human_attackPower;
	}

	public static int getHuman_attackPower2() { // getUserId 메서드를 통해 userId 값을 다른 클래스에서 가져오기 위한 메소드
		return human_attackPower;
	}

	public void setHuman_hp(int portion_drink) {
		human_hp += portion_drink;
		if (human_hp >= 300) {
			human_hp = 300;
			System.out.println("HP가 " + human_hp + " 이상이므로 물약을 더 먹을 필요가 없습니다.");
		} else if (human_hp < 0) {
			human_hp = 0;
		}
		System.out.println("현재 " + name + "님의 HP는? " + human_hp);
	}
	/*  진수가 뺌. store랑 엮어잇는 메소드
	public static void setHuman_hp2(int portion_drink) {
		human_hp += portion_drink;
		if (human_hp >= 300) {
			human_hp = 300;
			System.out.println("HP가 " + human_hp + " 이상이므로 더 오르지 않습니다.");
		} else if (human_hp < 0) {
			human_hp = 0;
		}
		// System.out.println("현재 " + name + "님의 HP는? " + human_hp);
	}
	*/

	public void setGold(int gold) {
		this.gold = gold;
	}

	public int getGold() { // getUserId 메서드를 통해 userId 값을 다른 클래스에서 가져오기 위한 메소드
		return gold;
	}

	// 여기다가 각종 피통, 공격력 다 박아주기

	public void drink(int portion_drink) {
		if (inventory.portion_count <= 0) {
			System.out.println("물약이 없으므로 물약을 더이상 사용하실수 없습니다.");
			inventory.portion_count = 0;
		} else {
			inventory.portion_count--;
			System.out.println("남은 물약 갯수는 " + inventory.portion_count);
			System.out.println("물약을 사용하였습니다.");
			human_hp = human_hp + portion_drink;
			System.out.println(name + "님의 현재 HP: " + human_hp);

			setHuman_hp(0);
		}

	}

	public void attack(Monster monster) {
		int new_attackPower = getHuman_attackPower(); // weapon_status 추가
		monster.hp -= new_attackPower;
		if (monster.hp <= 0) {
			monster.hp = 0;
		}
		System.out.println("몬스터에게 " + new_attackPower + "의 데미지를 입혔습니다.");
		System.out.println("몬스터의 남은 hp는? " + monster.hp);
	}

	public static void sleep(int sec) {// 주인공 2초 대기  // 진수 수정(다른 메소드에서 수월하게 부르기 위해 static으로
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void checkPlayerHP() {
		if (getHuman_hp() <= 0) {
			System.out.println(name + "님의 HP가 0 이하가 되었습니다. 게임 종료!");
			System.exit(0); // 현재 프로그램을 종료합니다.
		}
	}
	
	public void setJobNum(int jobNum) {
		this.jobNum = jobNum;
		// System.out.println("사용자가 정한 직업 숫자 " + this.jobNum);
	}
	
	public int getJobNum() {
		
		return jobNum;
	}
	
	public static int getJobNum2() {
		
		return jobNum;
	}
	
	public void humanAttackBoss(BossMonster bm) {
		int randomHit = (int) (Math.random() * 3) + 1;
		int human_attackPower = getHuman_attackPower();

		switch (randomHit) {
		case 1:
			bm.hp -= human_attackPower;
			if (bm.hp <= 0) {
				bm.hp = 0;
			}
			System.out.println("보스 몬스터에게 " + human_attackPower + "의 데미지를 입혔습니다.");
			System.out.println("보스 몬스터의 남은 hp는? " + bm.hp);
			break;
		case 2:
			bm.hp -= (int) human_attackPower * 0.9;
			if (bm.hp <= 0) {
				bm.hp = 0;
			}
			System.out.println("보스 몬스터에게 " + (int) (human_attackPower * 0.8) + "의 데미지를 입혔습니다.");
			System.out.println("보스 몬스터의 남은 hp는? " + bm.hp);
			break;
		case 3:
//			bm.hp -= (int) human_attackPower * 0.8;
//			if (bm.hp <= 0) {
//				bm.hp = 0;
//			}
			System.out.println("보스 몬스터가 " + name + "님의 공격을 회피하였습니다.");
			System.out.println("보스 몬스터의 남은 hp는? " + bm.hp);
			break;
		}
		
		/*
		 * if(bm.hp <=0 ) { bm.hp = 0; }
		 */
		
	}
	
}
package gameStart;

import java.util.Scanner;

public class Hunting {
	BossMonster bm = new BossMonster("Java", 70, 500);
	
	public static void main(String[] args) {

		Monster lv1Monster = new MonsterKind("lv1Monster", 15, 20);
		Monster lv2Monster = new MonsterKind("lv2Monster", 25, 60);
		
		MainCharacter player = new MainCharacter();
		Inventory inventory = new Inventory(); // 신진수 작업
		Store st = new Store();
		StoreDAO dao = new StoreDAO();
		Quest quest = new Quest();
		
		Scanner sc = new Scanner(System.in);
		/*
		int lv1MonsterDieCount = 1;// lv1 몬스터 죽은 회수 세어주기
		int number1 = 0;  // scanner 변수1
		int number2 = 0;  // scanner 변수2
		int number3 = 0;  // scanner 변수3
		int number4 = 0;  // scanner 변수4
		*/
		Opening.OpeningMessage();  // 오프닝 문을 사용하는 메소드
		player.setName(SelectJob.enterName(sc));
		SelectJob.JobSelect(sc, player);
		sc.nextLine();
		
		// 진수가 묶어버림 chapter 클래스에
		quest.startChapter("챕터1");	
		/* 진수가 chapter 메소드안에 넣어버림
		System.out.println("");
		System.out.println("챕터1 퀘스트를 시작합니다!");
		// player.sleep(2000);
		 */
		
		//public void questQuestion(MainCharacter mc, String monsterLv, int monsterCount, int monsterHeartCount) { // 챕터1, 2 사냥 시작전 메소드
		quest.questQuestion(player, "lv1Monster", 10, 0);
		/*// questQuestion(MainCharacter mc, String monsterLv) 메소드 사용
		System.out.println("lv1Monster를 10마리 잡으시오.");
		// player.sleep(2000);

		System.out.println("현재 " + player.getName() + " 님의 HP는" + player.getHuman_hp() + " 입니다.");
		// player.sleep(2000);
		System.out.println("사냥을 하러 가시겠습니까?");

		System.out.println("1. 예\t 2. 아니오\t ");
		
		number1 = sc.nextInt();
		// System.out.printf("입력하신 숫자는 %d입니다.\n", number1);
		
		while (number1 == 2) {
			System.out.println("퀘스트를 수행하기 위해서는 사냥을 해야합니다.");
			System.out.println("사냥을 하러 가시겠습니까?");
			System.out.println("사냥을 가지 않고 물약을 사용하려면 2를 눌러주십시오.");
			System.out.println("1. 사냥\t 2. 물약사용\t ");
			number1 = sc.nextInt();
			if (number1 == 2) {
				player.drink(100);// 100이 포션 한번 먹을때 차는 hp 양
			}
		}
		*/
		
		/*
		 * while(number1 != 1 && number1 !=2) { System.out.println("1 혹은 2만 입력해 주세요.");
		 * number1 = sc.nextInt(); }
		 */
		
		//quest.questHuntingCh1();  // 진수가 만든 메소드 / 아래 묵은거임
		/* questStartCh1(); 시작
		System.out.println("사냥을 시작합니다.");

		while (lv1MonsterDieCount <= 10) {
			while (lv1Monster.hp > 0) {
				System.out.println("");
				System.out.println("lv1Monster를 공격하시겠습니까?");
				System.out.println("1. 공격 \t 2. 포션먹기");
				number1 = sc.nextInt();
				if (number1 == 1) {
					System.out.println("lv1Monster를 공격합니다.");
					player.attack(lv1Monster);
					if (lv1Monster.hp <= 0) {
						System.out.println("lv1Monster를 잡았습니다!");
						System.out.println("");
						player.inventory.setPortion_count(SelectJob.getRandomPortion());// 포션 메소드
						inventory.getGold(); // 신진수 작업
						inventory.getTotal_money(); // 신진수 작업
						System.out.println(player.getName() + "님의 현재 HP : " + player.getHuman_hp());
						System.out.println("현재 잡은 몬스터 마릿수 : " + lv1MonsterDieCount);
						
					} else {
//                  System.out.println("남은 lv1Monster의 hp는 : " + lv1Monster.hp);
						lv1Monster.attack(player);
						player.checkPlayerHP();
					}
				} else if (number1 == 2) {
					player.drink(100);// 100이 포션 한번 먹을때 차는 양
					//System.out.println("물약을 사용하였습니다.");
				}
			}
			if (lv1MonsterDieCount < 10) {
				System.out.println("");
				System.out.println("새로운 몬스터 사냥을 시작합니다!");
			} else {
				System.out.println("챕터1 퀘스트를 클리어 하였습니다.");
				System.out.println("퀘스트 보상으로 300 골드를 추가 지급합니다.");
				// (코드로)인벤토리 클래스 내 토탈골드 + 300
				Inventory.total_money += 300;
				System.out.println("현재까지 " + player.getName() + "님이 보유한 총 골드 : " + inventory.total_money + "입니다.");
			}
			lv1Monster = new MonsterKind(null, 15, 20);
			lv1MonsterDieCount++;
		}
		
	questStartCh1();끝	*/
		
//		dao.initializeStock1();
//		dao.initializeStock2();
	    st.shopping();
	    
		System.out.println();

		// 진수가 묶어버림 chapter 클래스에
		quest.questQuestion(player, "lv2Monster", 0, 10);
	/* 진수가 다시 만듬
		System.out.println("챕터2 퀘스트를 시작합니다!");
		// player.sleep(2000);
	*/	
		//아래 메소드들 통합하는 메소드
		//quest.questQuestion2(player, "lv2Monster")  시작
		
		/*
		System.out.println("");
		
		System.out.println("lv2Monster의 심장을 10개 가져오시오.");
		// player.sleep(2000);
		System.out.println(player.getName() + "님의 HP는 " + player.getHuman_hp() + " 입니다.");
		// player.sleep(2000);

		System.out.println("사냥을 하러 가시겠습니까?");
		System.out.println("1. 예\t 2.아니오\t ");

		// 사용자가 숫자 말고 문자 혹은 문자열을 입력 했을 때 다시 입력하게 하는 while문
		while (!sc.hasNextInt()) {
			System.out.println("숫자를 입력해주세요. 다시 입력해주세요.");
			sc.next();
		}

		number2 = sc.nextInt();
		// System.out.printf("입력하신 숫자는 %d입니다.\n", number2);

		while (number2 == 2) {
			System.out.println("퀘스트를 수행하기 위해서는 사냥을 해야합니다.");
			System.out.println("사냥을 하러 가시겠습니까?");
			System.out.println("사냥을 가지 않고 물약을 사용하려면 2를 눌러주십시오.");
			System.out.println("1. 사냥\t 2. 물약사용\t ");
			number2 = sc.nextInt();
			if (number2 == 2) {
				player.drink(100);// 100이 포션 한번 먹을때 차는 hp 양
			}
		}
		quest.questQuestion2(player, "lv2Monster") 끝
		*/
		
		/*
		 * while(number2 != 1 && number2 !=2) { System.out.println("1 혹은 2만 입력해 주세요.");
		 * number2 = sc.nextInt(); }
		 */
		
		quest.questHuntingCh2();  //시작
		/*
		System.out.println("사냥을 시작합니다.");

		while (player.inventory.getLv2MonsterHeartCount() < 10) {
			while (lv2Monster.hp > 0) {
				System.out.println("");
				System.out.println("lv2Monster를 공격하시겠습니까?");
				System.out.println("1. 공격 \t 2. 포션먹기");
				number3 = sc.nextInt();

				if (number3 == 1) {
					System.out.println("lv2Monster를 공격합니다.");
					player.attack(lv2Monster);

					if (lv2Monster.hp <= 0) {
						System.out.println("lv2Monster를 잡았습니다!");
						player.inventory.setPortion_count(SelectJob.getRandomPortion());// 포션 메소드
						player.inventory.setLv2MonsterHeartCount(SelectJob.getRandomHeart());// 재료 메소드
						inventory.getGold2(); // 신진수 작업
						inventory.getTotal_money(); // 신진수 작업

					} else {
						lv2Monster.attack(player);
						player.checkPlayerHP();
					}
				} else if (number3 == 2) {
					player.drink(100);// 100이 포션 한번 먹을때 차는 양
					//System.out.println("물약을 사용하였습니다.");
					//System.out.println(player.getName() +  "님의 현재 HP : " + player.getHuman_hp());
				}
			}

			lv2Monster = new MonsterKind(null, 40, 100);

			if (player.inventory.getLv2MonsterHeartCount() < 10) {
				System.out.println("");
				System.out.println("새로운 몬스터 사냥을 시작합니다!");
				// System.out.println("현재 lv2MonsterHeartCount 값: " +
				// inventory.getLv2MonsterHeartCount());
			} else if (player.inventory.getLv2MonsterHeartCount() == 10) {
				System.out.println("");
				System.out.println("챕터2 퀘스트를 클리어 하였습니다.");
				System.out.println("퀘스트 보상으로 300 골드를 추가 지급합니다.");
				Inventory.total_money += 300;
				System.out.println(player.getName() + "님이 챕터2를 깰때까지 획득한 총 골드는 : " + inventory.total_money + "입니다.");// 신진수 작업

			}
		}
		System.out.println("챕터2 퀘스트를 클리어 하였습니다.");
		//quest.questStartCh2();  끝
		*/
	    st.shopping();
		// 보스레이드 챕터3
	    quest.startChapter("챕터3");
		/* 위에 quest.startChapter("챕터3"); 로 해결해버림 - 진수작업
	    System.out.println("챕터3 보스 퀘스트를 시작합니다.");
		System.out.println("보스 몬스터를 처치하십시오.");
		 */
	    
	    quest.bossStart();  // 보스 퀘스트만 불러오기  quest.bossStart();시작
		/*
	    while (bm.hp > 0) {
			System.out.println("보스 몬스터를 공격하시겠습니까?");
			System.out.println("1. 공격 \t 2. 포션먹기");
			number4 = sc.nextInt();
			if (number4 == 1) {
				System.out.println("보스 몬스터를 공격합니다.");
				player.humanAttackBoss(bm);
				if (bm.hp <= 0) {
					bm.hp = 0;
					System.out.println("보스 몬스터를 잡았습니다!");
				} else {
					bm.bossAttackHuman(player);
					player.checkPlayerHP();
				}
			} else if (number4 == 2) {
				player.drink(100);// 100이 포션 한번 먹을때 차는 양
				//System.out.println("물약을 사용하였습니다.");
			}
		}
		System.out.println("");
		System.out.println("챕터3 보스 퀘스트를 클리어 하였습니다.");
		System.out.println("퀘스트 보상으로 500 골드를 추가 지급합니다.");
		Inventory.total_money += 500;
		System.out.println("현재까지 " + player.getName() + "님이 보유한 총 골드 : " + inventory.total_money + "입니다."); // 신진수 작업
		quest.bossStart();시작
		*/
		System.out.println("모든 챕터 퀘스트를 완수하였습니다." + player.getName() + "님은 진정한 용사입니다.");
		System.out.println("-게임 끝-");
	}
}

package gameStart;

public class Inventory {
	public int gold; // 몹을 잡을 때 획득하는 골드
	public static int total_money = 0; // 최종 골드
	public int portion_count = 3; // 포션 갯수
	public int lv2MonsterHeartCount = 0;
	

	public int getLv2MonsterHeartCount() {
		return lv2MonsterHeartCount;
	}

	public void setLv2MonsterHeartCount(int lv2MonsterHeartCount) {
		this.lv2MonsterHeartCount += lv2MonsterHeartCount;
		System.out.println("현재 보유하고 있는 재료 갯수 : " + this.lv2MonsterHeartCount);
	}
	
	public int getPortion() {
		//던전 사냥시 획득한 포션갯수 추가되기
		return portion_count;
	}

	public void setPortion_count(int portion_count) {
		this.portion_count += portion_count;
		System.out.println("현재 보유하고 있는 포션 갯수 : " + this.portion_count);
	}
	
	/* 신진수 작업 */
	public int getGold() {
		gold = (int) (Math.random() * 41) + 10;
		System.out.println("추가로, 골드" + gold + " 를 획득하셨습니다.");
		return gold;
	}

	public int getTotal_money() {
		total_money += gold;
		System.out.println("현재 너가 보유한 골드 : " + total_money);
		return total_money;
	}

	public int getGold2() {
		gold = (int) (Math.random() * 81) + 20;
		System.out.println("그렇지만, 골드" + gold + " 는 획득하셨습니다.");
		return gold;
	}
	/* 신진수 작업 */
	
}
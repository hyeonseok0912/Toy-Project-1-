package gameStart;

public class BossMonster extends Monster {

	public BossMonster(String name, int attackPower, int hp) {
		super(name, attackPower, hp);
	}

	public void bossAttackHuman(MainCharacter player) {
		int human_hp = player.getHuman_hp();
		int criticalhit = (int) (Math.random() * 3) + 1;

		switch (criticalhit) {
		case 1:
			attack2(player, human_hp, attackPower);
			break;
		case 2:
			attack2(player, human_hp, attackPower * 2);
			break;
		case 3:
			attack2(player, human_hp, attackPower);
			break;
		}
		// human_hp -= attackPower;
	}
}

package gameStart;

public class MonsterKind extends Monster{

	public MonsterKind(String name, int attackPower, int hp) {
		super(name, attackPower, hp);
	}
	
}

package gameStart;

public class Ch3 {
   public void bossStart() {
      
      BossMonster bm = new BossMonster("Java", 70, 500);
      MainCharacter player = new MainCharacter();
      Inventory inventory = new Inventory();
      ChPublic cp = new ChPublic();
      
      while (bm.hp > 0) {
         System.out.println("보스 몬스터를 공격하시겠습니까?");
         System.out.println("1. 공격 \t 2. 포션먹기");
         
         //cp.scannerInt();
         
         if (cp.scannerInt() == 1) {
            System.out.println("보스 몬스터를 공격합니다.");
            player.humanAttackBoss(bm);
            if (bm.hp <= 0) {
               bm.hp = 0;
               System.out.println("보스 몬스터를 잡았습니다!");
            } else {
               bm.bossAttackHuman(player);
               player.checkPlayerHP();
            }
         } else if (cp.scannerInt() == 2) {
            player.drink(100);// 100이 포션 한번 먹을때 차는 양
            // System.out.println("물약을 사용하였습니다.");
         }
      }
      System.out.println("");
      System.out.println("챕터3 보스 퀘스트를 클리어 하였습니다.");
      System.out.println("퀘스트 보상으로 500 골드를 추가 지급합니다.");
      inventory.total_money += 500;
      System.out.println("현재까지 " + player.getName() + "님이 보유한 총 골드 : " + inventory.total_money + "입니다."); // 신진수 작업

   }
}
package gameStart;

import java.util.List;
import java.util.Scanner;

public class Store {
	StoreDAO dao = new StoreDAO();
	MainCharacter mc = new MainCharacter();  // 추가
	
	public Store() {
		dao.initializeStock1();
		dao.initializeStock2();
	}

	public void shopping() {
		System.out.println();
		// 전사 or 마법사 직업 가져오기
		if (MainCharacter.getJobNum2() == 1) {
			warriorShopping(null);
		} else if (MainCharacter.getJobNum2() == 2) {
			magicianShopping(null);
		}
	}

	// 전사 상점 메소드
	public void warriorShopping(Inventory i) {
		Scanner sc = new Scanner(System.in);
		// 시작 부분

		// 재고 출력

		/* welcome 문구 추가 */
		System.out.println("전사 상점에 오신 것을 환영합니다!");
		System.out.println("상점이 현재 가지고 있는 장비 목록을 알려드릴게요");
		System.out.println(MainCharacter.getName2() + "님의 현재 잔고: " + i.total_money + " 골드");
		showItemList1();
		System.out.println("1. 구매 2. 나가기");
		// 입력
		int buyOrNot = sc.nextInt();
		if (buyOrNot == 1) {
			// 구매
			System.out.println("구매할 상품 번호를 입력하세요.");
			// 구매할 상품 번호 입력
			int itemNo = sc.nextInt();

			System.out.println("선택하신 상품은 " + dao.itemName1(itemNo) + "입니다.");
			System.out.println("이 아이템을 구매하겠습니까?");
			System.out.println("1. 예 2. 아니오");
			int buyConfirm = sc.nextInt();

			if (buyConfirm == 1) {
				sellOrNot1(itemNo, i);
			} else if (buyConfirm == 2) {
				System.out.println("상점 카운터로 이동합니다.");
				warriorShopping(i);

			}
		} else if (buyOrNot == 2) {
			System.out.println("상점에서 나갑니다.");
			System.out.println();
			return;
		}

	}

	// 마법사 상점 메소드
	public void magicianShopping(Inventory i) {
		Scanner sc = new Scanner(System.in);
		// 시작 부분

		// 재고 출력

		/* welcome 문구 추가 */
		System.out.println("마법사 상점에 오신 것을 환영합니다!");
		System.out.println("상점이 현재 가지고 있는 장비 목록을 알려드릴게요");
		System.out.println(MainCharacter.getName2() + "님의 현재 잔고: " + i.total_money + " 골드");
		showItemList2();
		System.out.println("1. 구매 2. 나가기");
		// 입력
		int buyOrNot = sc.nextInt();
		if (buyOrNot == 1) {
			// 구매
			System.out.println("구매할 상품 번호를 입력하세요.");
			// 구매할 상품 번호 입력
			int itemNo = sc.nextInt();

			System.out.println("선택하신 상품은 " + dao.itemName2(itemNo) + "입니다.");
			System.out.println("이 아이템을 구매하겠습니까?");
			System.out.println("1. 예 2. 아니오");
			int buyConfirm = sc.nextInt();

			if (buyConfirm == 1) {
				sellOrNot2(itemNo, i);
			} else if (buyConfirm == 2) {
				System.out.println("상점 카운터로 이동합니다.");
				magicianShopping(i);

			}
		} else if (buyOrNot == 2) {
			System.out.println("상점에서 나갑니다.");
			System.out.println();
			return;
		}

	}

	// 재고출력 메소드 (전사용)
	public void showItemList1() {
		StoreDAO dao = new StoreDAO();
		List<StoreDTO> list = dao.itemList1();

		/* 표시되는 형태 수정 */
		System.out.printf(" %-5s || %-7s || %-14s || %-6s \n", "상품번호", "구 분", "장비이름", "가격");
	      System.out.println("==================================================================");
		for (StoreDTO e : list) {
			System.out.printf(" %-9d || %-9s || %-11s || %-9d \n", e.getNumber(), e.getCode(), e.getName(),
					e.getPrice());
		}

	}

	// 재고출력 메소드 (마법사용)
	public void showItemList2() {
		StoreDAO dao = new StoreDAO();
		List<StoreDTO> list = dao.itemList2();

		/* 표시되는 형태 수정 */
		System.out.printf(" %-5s || %-7s || %-16s || %-6s \n", "상품번호", "구 분", "장비이름", "가격");
		System.out.println("==================================================================");
		for (StoreDTO e : list) {
			System.out.printf(" %-9d || %-9s || %-12s || %-9d \n", e.getNumber(), e.getCode(), e.getName(),
					e.getPrice());
		}

	}

	// 가격 확인 (전사용)
	public void sellOrNot1(int itemNo, Inventory i) {
		StoreDAO dao = new StoreDAO();
		int price = dao.itemPrice1(itemNo);
		String itemName = dao.itemName1(itemNo);
		if (i.total_money < price) {
			System.out.println("가진 돈: " + i.total_money + "골드");
			System.out.println("상품 가격: " + price + "골드");
			System.out.println("골드가 부족합니다.");
			System.out.println("다시 상점으로 이동합니다.");
			System.out.println();
			warriorShopping(i);
		} else {
			System.out.println(i.total_money + "골드로 " + price + "골드의 " + itemName + " 장비를 구매합니다.");
			sellItem1(itemNo, i);
		}
	}

	// 가격 확인 (마법사용)
	public void sellOrNot2(int itemNo, Inventory i) {
		StoreDAO dao = new StoreDAO();
		int price = dao.itemPrice2(itemNo);
		String itemName = dao.itemName2(itemNo);
		if (i.total_money < price) {
			System.out.println("가진 돈: " + i.total_money + "골드");
			System.out.println("상품 가격: " + price + "골드");
			System.out.println("골드가 부족합니다.");
			System.out.println("다시 상점으로 이동합니다.");
			System.out.println();
			magicianShopping(i);
		} else {
			System.out.println(i.total_money + "골드로 " + price + "골드의 " + itemName + " 장비를 구매합니다.");
			sellItem2(itemNo, i);
		}
	}

	// 거래메소드 (전사용)
	public void sellItem1(int itemNo, Inventory i) {

		// db에서 팔림 표시
		dao.stockOut1(itemNo);
		System.out.println();
		// player 스테이터스 올리기
		int itemAttack = dao.itemStatus1(itemNo).get("attack");
		int itemHp = dao.itemStatus1(itemNo).get("hp");
		MainCharacter.setHuman_attackPower2(itemAttack);
		System.out.println("공격력이 " + itemAttack + "만큼 증가하여, 현재 공격력은 " + MainCharacter.getHuman_attackPower2() + "입니다.");
		//MainCharacter.setHuman_hp2(itemHp);   아래 문장이 진수 작업
		mc.setHuman_hp(itemHp);
		
		//System.out.println("체력이 " + itemHp + "만큼 증가하여, 현재 체력은 " + MainCharacter.getHuman_hp2() + "입니다.");   // 아래 문장이 진수 작업
		System.out.println("체력이 " + itemHp + "만큼 증가하여, 현재 체력은 " + mc.getHuman_hp() + "입니다.");

		// player 돈 빼기
		int price = dao.itemPrice1(itemNo);
		i.total_money -= price;
		System.out.println("구매 후, " + MainCharacter.getName2() + "님의 잔고는 " + i.total_money + "골드입니다.");

		// 상점으로 이동
		Scanner sc = new Scanner(System.in);
		System.out.println("1. 상점 카운터로 2. 상점 나가기");
		int input = sc.nextInt();
		if (input == 1) {
			System.out.println("다시 상점으로 이동합니다.");
			warriorShopping(i);
		} else if (input == 2) {
			System.out.println("상점에서 나갑니다.");
			System.out.println();
			return;
		}

	}

	// 거래메소드 (마법사용)
	public void sellItem2(int itemNo, Inventory i) {

		// db에서 팔림 표시
		dao.stockOut2(itemNo);
		System.out.println();
		// player 스테이터스 올리기
		int itemAttack = dao.itemStatus2(itemNo).get("attack");
		int itemHp = dao.itemStatus2(itemNo).get("hp");
		MainCharacter.setHuman_attackPower2(itemAttack);
		System.out.println("공격력이 " + itemAttack + "만큼 증가하여, 현재 공격력은 " + MainCharacter.getHuman_attackPower2() + "입니다.");
		//MainCharacter.setHuman_hp2(itemHp);   아래가 진수 작업
		mc.setHuman_hp(itemHp);
		//System.out.println("체력이 " + itemHp + "만큼 증가하여, 현재 체력은 " + MainCharacter.getHuman_hp2() + "입니다.");  아래가 진수 작업
		System.out.println("체력이 " + itemHp + "만큼 증가하여, 현재 체력은 " + mc.getHuman_hp() + "입니다.");

		// player 돈 빼기
		int price = dao.itemPrice2(itemNo);
		i.total_money -= price;
		System.out.println("구매 후, " + MainCharacter.getName2() + "님의 잔고는 " + i.total_money + "골드입니다.");

		// 상점으로 이동
		Scanner sc = new Scanner(System.in);
		System.out.println("1. 상점 카운터로 2. 상점 나가기");
		int input = sc.nextInt();
		if (input == 1) {
			System.out.println("다시 상점으로 이동합니다.");
			magicianShopping(i);
		} else if (input == 2) {
			System.out.println("상점에서 나갑니다.");
			System.out.println();
			return;
		}

	}
}
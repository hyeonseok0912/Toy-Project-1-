package gameStart;

import java.util.Scanner;

public class Opening {
		
	public static void OpeningMessage() {
		MainCharacter player = new MainCharacter();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("- 자바의 전설 - 게임을 시작합니다.");
		System.out.println("게임 제작자는 백건하, 손현석, 이민우, 이진선, 신진수 입니다.");
		
		player.sleep(2000);
		System.out.println("");
		System.out.println("♥ 매주 업데이트되고 있으니 많은 사랑과 관심 부탁 드립니다 ♥");
		System.out.println("게임을 시작하려면 아무 키를 눌러주시기 바랍니다.");
		player.setName(SelectJob.enterName(sc));
		SelectJob.JobSelect(sc, player);
		
	}
}
package gameStart;

public class Monster {

	// SelectJob selectjob = new SelectJob();

	public String name;
	public int attackPower;// 공격력
	public int hp;// 체력

	public Monster(String name, int attackPower, int hp) {
		this.name = name;
		this.attackPower = attackPower;
		this.hp = hp;
	}

	public void attack(MainCharacter player) {

		// player.getHuman_hp();

		System.out.println("몬스터의 턴입니다.");
		System.out.println("");
		System.out.println("몬스터가 " + player.getName() + "님에게 " + attackPower + "의 피해를 입혔습니다.");

		player.setHuman_hp(-attackPower);
	}

	public static void attack2(MainCharacter player, int human_hp, int attackPower) {

		// player.getHuman_hp();
		
		System.out.println("");
		System.out.println("보스 몬스터의 턴입니다.");
		System.out.println("보스 몬스터가 " + player.getName() + "님에게 " + attackPower + "의 피해를 입혔습니다.");

		player.setHuman_hp(-attackPower);
//		System.out.println("당신의 남은 HP는? " + player.getHuman_hp());
	}
	

}

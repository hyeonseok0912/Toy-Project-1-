package gameStart;

import java.util.Scanner;

public class Quest extends Hunting {
	Hunting h = new Hunting();
	MainCharacter player = new MainCharacter();
	Inventory inventory = new Inventory(); // 신진수 작업
	Monster lv1Monster = new MonsterKind("lv1Monster", 15, 20);
	Monster lv2Monster = new MonsterKind("lv2Monster", 25, 60);

	Scanner sc = new Scanner(System.in);
	int number1 = 0; // scanner 변수1
	// number1로 써도 충분할듯
	/*
	 * int number2 = 0; // scanner 변수2 int number3 = 0; // scanner 변수3 int number4 =
	 * 0; // scanner 변수4
	 */

	public void startChapter(String questNum) {
		System.out.println("");
		if (questNum.equals("챕터1") || questNum.equals("챕터2")) {
			System.out.println(questNum + " 퀘스트를 시작합니다!");

		} else if (questNum.equals("챕터3")) {
			System.out.println(questNum + " 보스 퀘스트를 시작합니다.");
			System.out.println("보스 몬스터를 처치하십시오.");
		}
		// player.sleep(2000);
		MainCharacter.sleep(2000); // sleep메소드를 static으로 바꿈. 매번 객체 생성 하지 않게

	}

	/*
	 * public void Quest(MainCharacter mc, Hunting h) {
	 * 
	 * System.out.println("lv1Monster를 10마리 잡으시오."); // player.sleep(2000);
	 * 
	 * System.out.println("현재 " + mc.getName() + " 님의 HP는" + mc.getHuman_hp() +
	 * " 입니다."); // player.sleep(2000); System.out.println("사냥을 하러 가시겠습니까?");
	 * System.out.println("1. 예\t 2. 아니오\t ");
	 * 
	 * number1 = sc.nextInt(); // System.out.printf("입력하신 숫자는 %d입니다.\n", number1);
	 * 
	 * while (number1 == 2) { System.out.println("퀘스트를 수행하기 위해서는 사냥을 해야합니다.");
	 * System.out.println("사냥을 하러 가시겠습니까?");
	 * System.out.println("사냥을 가지 않고 물약을 사용하려면 2를 눌러주십시오.");
	 * System.out.println("1. 사냥\t 2. 물약사용\t "); number1 = sc.nextInt(); if (number1
	 * == 2) { mc.drink(100);// 100이 포션 한번 먹을때 차는 hp 양 } } }
	 */

	public void questQuestion(MainCharacter mc, String monsterLv, int monsterCount, int monsterHeartCount) { // 챕터1, 2 사냥 시작전 메소드

		if (monsterLv.equals("lv1Monster")) {
			System.out.println(monsterLv + "를 " + monsterCount + "마리 잡으시오.");
			// player.sleep(2000);
		} else if (monsterLv.equals("lv2Monster")) {
			System.out.println(monsterLv + "의 심장을 " + monsterHeartCount + "개 가져오시오.");
			// player.sleep(2000);
		}

		System.out.println("현재 " + mc.getName() + " 님의 HP는" + mc.getHuman_hp() + " 입니다.");
		// player.sleep(2000);
		System.out.println("사냥을 하러 가시겠습니까?");
		System.out.println("1. 예\t 2. 아니오\t ");

		number1 = sc.nextInt();
		// System.out.printf("입력하신 숫자는 %d입니다.\n", number1);

		if (monsterLv.equals("lv1Monster")) {
			A:while (number1 == 2) {
				System.out.println("퀘스트를 수행하기 위해서는 사냥을 해야합니다.");
				System.out.println("사냥을 하러 가시겠습니까?");
				System.out.println("사냥을 가지 않고 물약을 사용하려면 2를 눌러주십시오.");
				System.out.println("1. 사냥\t 2. 물약사용\t ");
				number1 = sc.nextInt();
				if (number1 == 2) {
					mc.drink(100);// 100이 포션 한번 먹을때 차는 hp 양
				}else if(number1 == 1){
					break;
				}else {
					break A;
				}
			}
		} else if (monsterLv.equals("lv2Monster")) {
			B:while (number1 == 2) {
				System.out.println("퀘스트를 수행하기 위해서는 사냥을 해야합니다.");
				System.out.println("사냥을 하러 가시겠습니까?");
				System.out.println("사냥을 가지 않고 물약을 사용하려면 2를 눌러주십시오.");
				System.out.println("1. 사냥\t 2. 물약사용\t ");
				number1 = sc.nextInt();
				if (number1 == 2) {
					mc.drink(100);// 100이 포션 한번 먹을때 차는 hp 양
				}else if(number1 == 1){
					break;
				}else {
					break B;
				}
			}
		}
	}

	public void questHuntingCh1(String monsterLv, int lv1MonsterDieCount, int Lv2MonsterHeartCount) {  // 본격적인 퀘스트
		//int lv1MonsterDieCount = 1;
		
		System.out.println("사냥을 시작합니다.");
		
		while ((lv1MonsterDieCount <= 10 && lv1MonsterDieCount > 0) || Lv2MonsterHeartCount <= 10 && Lv2MonsterHeartCount > 0) {
			while (lv1Monster.hp > 0) {
				System.out.println("");
				System.out.println("lv1Monster를 공격하시겠습니까?");
				System.out.println("1. 공격 \t 2. 포션먹기");
				number1 = sc.nextInt();
				if (number1 == 1) {
					System.out.println("lv1Monster를 공격합니다.");
					player.attack(lv1Monster);
					if (lv1Monster.hp <= 0) {
						System.out.println("lv1Monster를 잡았습니다!");
						System.out.println("");
						player.inventory.setPortion_count(SelectJob.getRandomPortion());// 포션 메소드
						inventory.getGold(); // 신진수 작업
						inventory.getTotal_money(); // 신진수 작업
						System.out.println(player.getName() + "님의 현재 HP : " + player.getHuman_hp());
						System.out.println("현재 잡은 몬스터 마릿수 : " + lv1MonsterDieCount);

					} else {
//                  System.out.println("남은 lv1Monster의 hp는 : " + lv1Monster.hp);
						lv1Monster.attack(player);
						player.checkPlayerHP();
					}
				} else if (number1 == 2) {
					player.drink(100);// 100이 포션 한번 먹을때 차는 양
					// System.out.println("물약을 사용하였습니다.");
				}
			}
			if (lv1MonsterDieCount < 10) {
				System.out.println("");
				System.out.println("새로운 몬스터 사냥을 시작합니다!");
			} else {
				System.out.println("챕터1 퀘스트를 클리어 하였습니다.");
				System.out.println("퀘스트 보상으로 300 골드를 추가 지급합니다.");
				// (코드로)인벤토리 클래스 내 토탈골드 + 300
				Inventory.total_money += 300;
				System.out.println("현재까지 " + player.getName() + "님이 보유한 총 골드 : " + inventory.total_money + "입니다.");
			}
			lv1Monster = new MonsterKind(null, 15, 20);
			lv1MonsterDieCount++;
		}

	}

	public void questHuntingCh2() {
		System.out.println("사냥을 시작합니다.");

		while (player.inventory.getLv2MonsterHeartCount() < 10) {
			while (lv2Monster.hp > 0) {
				System.out.println("");
				System.out.println("lv2Monster를 공격하시겠습니까?");
				System.out.println("1. 공격 \t 2. 포션먹기");
				number1 = sc.nextInt();

				if (number1 == 1) {
					System.out.println("lv2Monster를 공격합니다.");
					player.attack(lv2Monster);

					if (lv2Monster.hp <= 0) {
						System.out.println("lv2Monster를 잡았습니다!");
						player.inventory.setPortion_count(SelectJob.getRandomPortion());// 포션 메소드
						player.inventory.setLv2MonsterHeartCount(SelectJob.getRandomHeart());// 재료 메소드
						inventory.getGold2(); // 신진수 작업
						inventory.getTotal_money(); // 신진수 작업

					} else {
						lv2Monster.attack(player);
						player.checkPlayerHP();
					}
				} else if (number1 == 2) {
					player.drink(100);// 100이 포션 한번 먹을때 차는 양
					// System.out.println("물약을 사용하였습니다.");
					// System.out.println(player.getName() + "님의 현재 HP : " + player.getHuman_hp());
				}
			}

			lv2Monster = new MonsterKind(null, 40, 100);

			if (player.inventory.getLv2MonsterHeartCount() < 10) {
				System.out.println("");
				System.out.println("새로운 몬스터 사냥을 시작합니다!");
				// System.out.println("현재 lv2MonsterHeartCount 값: " +
				// inventory.getLv2MonsterHeartCount());
			} else if (player.inventory.getLv2MonsterHeartCount() == 10) {
				System.out.println("");
				System.out.println("챕터2 퀘스트를 클리어 하였습니다.");
				System.out.println("퀘스트 보상으로 300 골드를 추가 지급합니다.");
				Inventory.total_money += 300;
				System.out.println(player.getName() + "님이 챕터2를 깰때까지 획득한 총 골드는 : " + inventory.total_money + "입니다.");// 신진수
																													// 작업

			}
		}
		System.out.println("챕터2 퀘스트를 클리어 하였습니다.");
	}

	public void bossStart() {

		while (bm.hp > 0) {
			System.out.println("보스 몬스터를 공격하시겠습니까?");
			System.out.println("1. 공격 \t 2. 포션먹기");
			number1 = sc.nextInt();
			if (number1 == 1) {
				System.out.println("보스 몬스터를 공격합니다.");
				player.humanAttackBoss(bm);
				if (bm.hp <= 0) {
					bm.hp = 0;
					System.out.println("보스 몬스터를 잡았습니다!");
				} else {
					bm.bossAttackHuman(player);
					player.checkPlayerHP();
				}
			} else if (number1 == 2) {
				player.drink(100);// 100이 포션 한번 먹을때 차는 양
				// System.out.println("물약을 사용하였습니다.");
			}
		}
		System.out.println("");
		System.out.println("챕터3 보스 퀘스트를 클리어 하였습니다.");
		System.out.println("퀘스트 보상으로 500 골드를 추가 지급합니다.");
		Inventory.total_money += 500;
		System.out.println("현재까지 " + player.getName() + "님이 보유한 총 골드 : " + inventory.total_money + "입니다."); // 신진수 작업

	}
}
package gameStart;

public class ChPublic {
	
	public void startChapter(String questNum) {
		System.out.println("");
		if (questNum.equals("챕터1") || questNum.equals("챕터2")) {
			System.out.println(questNum + " 퀘스트를 시작합니다!");

		} else if (questNum.equals("챕터3")) {
			System.out.println(questNum + " 보스 퀘스트를 시작합니다.");
			System.out.println("보스 몬스터를 처치하십시오.");
		}
		// player.sleep(2000);
		MainCharacter.sleep(2000); // sleep메소드를 static으로 바꿈. 매번 객체 생성 하지 않게
		
	}
	
	public void questQuestion(MainCharacter mc, String monsterLv, int monsterCount, int monsterHeartCount) { // 챕터1, 2 사냥 시작전 메소드
		if (monsterLv.equals("lv1Monster")) {
			System.out.println(monsterLv + "를 " + monsterCount + "마리 잡으시오.");
			// player.sleep(2000);
		} else if (monsterLv.equals("lv2Monster")) {
			System.out.println(monsterLv + "의 심장을 " + monsterHeartCount + "개 가져오시오.");
			// player.sleep(2000);
		}

		System.out.println("현재 " + mc.getName() + " 님의 HP는" + mc.getHuman_hp() + " 입니다.");
		// player.sleep(2000);
		System.out.println("사냥을 하러 가시겠습니까?");
		System.out.println("1. 예\t 2. 아니오\t ");

		number1 = sc.nextInt();
		// System.out.printf("입력하신 숫자는 %d입니다.\n", number1);

		if (monsterLv.equals("lv1Monster")) {
			A:while (number1 == 2) {
				System.out.println("퀘스트를 수행하기 위해서는 사냥을 해야합니다.");
				System.out.println("사냥을 하러 가시겠습니까?");
				System.out.println("사냥을 가지 않고 물약을 사용하려면 2를 눌러주십시오.");
				System.out.println("1. 사냥\t 2. 물약사용\t ");
				number1 = sc.nextInt();
				if (number1 == 2) {
					mc.drink(100);// 100이 포션 한번 먹을때 차는 hp 양
				}else if(number1 == 1){
					break;
				}else {
					break A;
				}
			}
		} else if (monsterLv.equals("lv2Monster")) {
			B:while (number1 == 2) {
				System.out.println("퀘스트를 수행하기 위해서는 사냥을 해야합니다.");
				System.out.println("사냥을 하러 가시겠습니까?");
				System.out.println("사냥을 가지 않고 물약을 사용하려면 2를 눌러주십시오.");
				System.out.println("1. 사냥\t 2. 물약사용\t ");
				number1 = sc.nextInt();
				if (number1 == 2) {
					mc.drink(100);// 100이 포션 한번 먹을때 차는 hp 양
				}else if(number1 == 1){
					break;
				}else {
					break B;
				}
			}
		}
	}
	
}
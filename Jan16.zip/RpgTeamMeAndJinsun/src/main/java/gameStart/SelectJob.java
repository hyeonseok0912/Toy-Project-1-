package gameStart;

import java.util.Scanner;

public class SelectJob {
	MainCharacter mc = new MainCharacter();
	static int gold;
	static int human_attackPower; // 1~5
	static int human_hp; // 200~300
	// 기본 스탯

	//private static String userId;
	// public String userId;

	public static String enterName(Scanner sc) {
		// public String enterName() {

		// Scanner scan = new Scanner(System.in);
		// String userId = "";
		boolean nameCon = false; // false

		do {
			System.out.println("당신의 이름을 입력하세요.");
			MainCharacter.name = sc.nextLine();

			System.out.println("당신의 이름은 " + MainCharacter.name + "가 맞습니까?");
			System.out.println("맞으면 엔터, 이름을 재 재설정하시려면 엔터를 제외한 다른 키를 눌러주시기 바랍니다.");
			String enter = sc.nextLine();

			if (enter.isEmpty()) {
				nameCon = true;
			}
		} while (!nameCon);

		return MainCharacter.name;
	}

	public static void JobSelect(Scanner sc, MainCharacter mc) {
		System.out.println(mc.getName() + "님 직업을 선택해주시기 바랍니다.");
		System.out.println("직업은 1. 전사\t2. 마법사" + "가 있습니다.");

		System.out.println("둘 중 하나를 선택해주세요.");
		int jobNum = sc.nextInt();

		// 직업 선택할 때 조건문
		if (jobNum != 1 && jobNum != 2) {
			System.out.println("잘못 선택하셨습니다.");
			System.out.println("숫자 1(전사) 혹은 숫자 2(마법사)를 입력해주세요.");
		} else if (jobNum == 1) {
			System.out.println("┌────────────────────────────────┐");
			System.out.println("│  당신은 전사를 선택하셨습니다. │");
			System.out.println("└────────────────────────────────┘");
			System.out.println("");
			System.out.println("       '/'");
			System.out.println("      '/'    Power Slash !!");
			System.out.println("   O '/'");
			System.out.println("  /|\'*'");
			System.out.println("   |");
			System.out.println("  / ＼");
			System.out.println("=================================");
			
			human_attackPower = (int) (Math.random() * 5) + 18; // 1~5
			human_hp = (int) (Math.random() * 201) + 100; // 200~300
			
			//mc.sleep(2000);
			System.out.println(MainCharacter.name + "님의 기본 공격력은 " + human_attackPower);
			System.out.println(MainCharacter.name + "님의 기본 체력은 " + human_hp);
			System.out.println("시작 골드는 " + gold);

		} else if (jobNum == 2) {

			System.out.println("┌─────────────────────────────────┐");
			System.out.println("│ 당신은 마법사를 선택하셨습니다. │");
			System.out.println("└─────────────────────────────────┘");
			System.out.println("");
			System.out.println("    O '*'     ＼ /");
			System.out.println("   /|\'/'        x    Magic Claw !!");
			System.out.println("    |          /  ＼");
			System.out.println("   / ＼");
			System.out.println("==================================");

			human_attackPower = (int) (Math.random() * 5) + 22; // 5~10
			human_hp = (int) (Math.random() * 101) + 100; // 100~200

			//mc.sleep(2000);
			System.out.println(MainCharacter.name + "님의 기본 공격력은 " + human_attackPower);
			System.out.println(MainCharacter.name + "님의 기본 체력은 " + human_hp);
			System.out.println("시작 골드는 " + gold);
		}
		mc.setGold(gold);
		mc.setHuman_attackPower(human_attackPower);
		mc.setHuman_hp(human_hp);
		
		mc.setJobNum(jobNum);
	}

	public static int getRandomPortion() {
		int num = mathrandom1();
		if (num == 1) {
			System.out.println("포션을 한개 획득했습니다.");
		}
		return num;
	}

	public static int mathrandom1() {
		return (int) (Math.random() * 2);
	}

	public static int getRandomHeart() {
		int num = mathrandom2();
		if (num == 1) {
			System.out.println("재료를 한개 획득했습니다.");
		}
		return num;
	}

	public static int mathrandom2() {
		return (int) (Math.random() * 2);
	}
}
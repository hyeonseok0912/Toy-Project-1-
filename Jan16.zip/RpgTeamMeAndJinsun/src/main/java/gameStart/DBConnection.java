package gameStart;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	//Singleton
	private static DBConnection dbConn = new DBConnection();
	private DBConnection() {}
	public static DBConnection getInstance() {
		return dbConn;
	}
	
	public Connection getConn() {
      Connection conn = null;
      
      try {
         Class.forName("org.mariadb.jdbc.Driver");
         String url = "jdbc:mariadb://guro.wisejia.com:3307/c23c_09";
         conn = DriverManager.getConnection(url, "c23c_09", "1234");

      } catch (ClassNotFoundException e) {
         e.printStackTrace();

      } catch (SQLException e) {
         e.printStackTrace();
      }
      return conn;
   }
}